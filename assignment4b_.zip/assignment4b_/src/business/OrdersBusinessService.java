package business;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;

import beans.Order;

@Stateless
@Local(OrdersBusinessInterface.class)
@LocalBean
@Alternative 

public class OrdersBusinessService implements OrdersBusinessInterface {

	List<Order> orders = new ArrayList<Order>();
    /**
     * Default constructor. 
     */
    public OrdersBusinessService()
    {
    	this.orders.add(new Order("0001", "Gibson", (float) 599.99, 3));
		this.orders.add(new Order("0002", "Fender", (float) 699.99, 5));
		this.orders.add(new Order("0003", "Taylor", (float) 799.99, 3));
		this.orders.add(new Order("0004", "Martin", (float) 499.99, 2));
		this.orders.add(new Order("0005", "Takamine", (float) 299.99, 5));
		this.orders.add(new Order("0006", "Pono", (float) 79.99, 6));
		this.orders.add(new Order("0007", "Kamaka", (float) 99.99, 7));
		this.orders.add(new Order("0008", "Twelver", (float) 999.99, 2));
		this.orders.add(new Order("0009", "Guilele", (float) 199.99, 4));
		this.orders.add(new Order("0010", "8-String", (float) 99.99, 5));
    }

	/**
     * @see OrdersBusinessInterface#test()
     */
    public void test() 
    {
    	System.out.println("Hey there from the OrdersBusinessService.");
        
    }

	@Override
	public List<Order> getOrders() 
	{		
		return orders;
	}

	@Override
	public void setOrders(List<Order> orders)
	{
		this.orders = orders;
	}

}
