package business;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;

import beans.Order;


/**
 * Session Bean implementation class AnotherOrdersBusinessService
 */
@Alternative
@Stateless
@Local(OrdersBusinessInterface.class)
@LocalBean
public class AnotherOrdersBusinessService implements OrdersBusinessInterface {

	List<Order> orders = new ArrayList<Order>();
    /**
     * Default constructor. 
     */
    public AnotherOrdersBusinessService() 
    {
    	this.orders.add(new Order("0001a", "Gibson", (float) 599.99, 3));
		this.orders.add(new Order("0002a", "Fender", (float) 699.99, 5));
		this.orders.add(new Order("0003a", "Taylor", (float) 799.99, 3));
		this.orders.add(new Order("0004a", "Martin", (float) 499.99, 2));
		this.orders.add(new Order("0005a", "Takamine", (float) 299.99, 5));
		this.orders.add(new Order("0006a", "Pono", (float) 79.99, 6));
		this.orders.add(new Order("0007a", "Kamaka", (float) 99.99, 7));
		this.orders.add(new Order("0008a", "Twelver", (float) 999.99, 2));
		this.orders.add(new Order("0009a", "Guilele", (float) 199.99, 4));
		this.orders.add(new Order("0010a", "8-String", (float) 99.99, 5));
    }

	/**
     * @see OrdersBusinessInterface#test()
     */
    public void test() 
    {
    	System.out.println("Hey there from AnotherOrdersBusinessService.");
        // TODO Auto-generated method stub
    }

	@Override
	public List<Order> getOrders() {
		// TODO Auto-generated method stub
		return orders;
	}

	@Override
	public void setOrders(List<Order> orders) 
	{
		this.orders = orders;
	}

}
