package controllers;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import beans.User;
import business.OrdersBusinessInterface;

@ManagedBean
@ViewScoped 

public class FormController {

	@Inject
	OrdersBusinessInterface service;
	
	public String onSubmit() 
	{ //Get the User Managed Bean FacesContext context =
	  FacesContext context = FacesContext.getCurrentInstance();
	  User user = context.getApplication().evaluateExpressionGet(context, "#{user}",User.class);
	  
	  //Call Business Service(for testing)
	  service.test();
	  
	  //Forward to the TestResponseView along with the User Managed Bean
	  FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("user", user);
	  return "DataGrid.xhtml"; 
	}
	public OrdersBusinessInterface getService() 
	{
		return service;
	}
}
