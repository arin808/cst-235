package beans;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="Order")

public class Order 
{
	
	int orderID = 0;
	String orderNum = "";
	String prodName = "";
	float price = 0;
	int quant = 0;
	
	public Order(int orderId, String orderNumber, String productName, float cost, int quantity)
	{
		this.orderID = orderId;
		this.orderNum = orderNumber;
		this.prodName = productName;
		this.price = cost;
		this.quant = quantity;
	}
	public Order()
	{
		
	}
	public int getOrderID() {
		return orderID;
	}

	public void setOrderID(int orderID) {
		this.orderID = orderID;
	}

	public String getOrderNum() {
		return orderNum;
	}

	public void setOrderNum(String orderNum) {
		this.orderNum = orderNum;
	}

	public String getProdName() {
		return prodName;
	}

	public void setProdName(String prodName) {
		this.prodName = prodName;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public int getQuant() {
		return quant;
	}

	public void setQuant(int quant) {
		this.quant = quant;
	}
	

}
