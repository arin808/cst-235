package business;


import java.io.Serializable;
import java.util.List;

import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;

import beans.Order;
import data.OrdersDataService;

@Stateless
@Local(OrdersBusinessInterface.class)
@LocalBean
@Alternative 


public class OrdersBusinessService implements OrdersBusinessInterface 
{
	@Resource(mappedName="java:/ConnectionFactory")
	private ConnectionFactory connectionFactory;
	
	@Resource(mappedName="java:/jms/queue/Order")
	private Queue queue;
	
	@Override
	public void sendOrder(Order order) 
	{
		//send message for Order
		try
		{
			//establish connection
			Connection connection = connectionFactory.createConnection();
			Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			
			//create producer to send messages
			MessageProducer messageProducer = session.createProducer(queue);
			
			//create and send text message
			TextMessage message1 = session.createTextMessage();
			message1.setText("This is a test message");
			messageProducer.send(message1);
			
			//create and send message object of type order
			ObjectMessage message2 = session.createObjectMessage();
			message2.setObject(order);
			messageProducer.send(message2);
			
			connection.close();
		}
		catch (JMSException e)
		{
			e.printStackTrace();
		}
	}
	
	@EJB
	OrdersDataService service;
	
    public void test() 
    {
    	System.out.println("Hey there from the OrdersBusinessService.");
    }

	@Override
	public List<Order> getOrders() 
	{	
		return service.findAll();
	}

	public boolean deleteOrder(Order order)
	{
		return service.delete(order);
	}

	
	public Order findById(int id) 
	{
		return service.findById(id);
	}

	
	public boolean insertOrder(Order order) 
	{
		return service.create(order);
	}

	
	public boolean updateOrder(Order order) 
	{
		return service.update(order);
	}

	@Override
	public void setOrders(List<Order> orders) {
	
		
	}

}
