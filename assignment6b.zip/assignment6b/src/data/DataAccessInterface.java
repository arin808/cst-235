package data;

import java.util.List;

public interface DataAccessInterface <Order>
{
	public List<Order> findAll();
}
