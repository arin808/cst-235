package beans;

import javax.faces.bean.ManagedBean;

@ManagedBean

public class Bibleverse 
{
	int book = 0;
	int chapter = 0;
	int verse = 0;
	String text = "";
	
	public Bibleverse(int book, int chapter, int verse, String text)
	{
		this.book = book;
		this.chapter = chapter;
		this.verse = verse;
		this.text = text;
	}
	public Bibleverse()
	{
		
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public int getBook() {
		return book;
	}
	public void setBook(int book) {
		this.book = book;
	}
	public int getChapter() {
		return chapter;
	}
	public void setChapter(int chapter) {
		this.chapter = chapter;
	}
	public int getVerse() {
		return verse;
	}
	public void setVerse(int verse) {
		this.verse = verse;
	}
}
