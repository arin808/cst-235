package business;

import java.util.List;

import javax.ejb.Local;

import beans.Bibleverse;

@Local

public interface BibleBusinessInterface 
{
	public void test();
	
	public List<Bibleverse> findByAddress(int book, int chapter, int verse);
	
	public void setBibleverse(List<Bibleverse> bv);
}
