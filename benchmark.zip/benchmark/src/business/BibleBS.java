package business;

import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;
import javax.inject.Inject;

import beans.Bibleverse;
import data.BibleDS;

@Stateless
@Local(BibleBusinessInterface.class)
@LocalBean
@Alternative

public class BibleBS implements BibleBusinessInterface 
{
	
	BibleDS service = new BibleDS();

	List<Bibleverse> bv = new ArrayList<Bibleverse>();
	
    public void test() 
    {
    	System.out.println("============Hey there from the BibleBS===============");
    }
	    
    @Override
    public List<Bibleverse> findByAddress(int book, int chapter, int verse) 
    {
    	//service.findByAddress(book, chapter, verse);
    	
    	return service.findByAddress(book, chapter, verse); 
    }

	@Override
	public void setBibleverse(List<Bibleverse> bv) {
		// TODO Auto-generated method stub
		
	}
}
