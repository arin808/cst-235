package business;

import java.util.ArrayList;
import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import beans.Bibleverse;
import data.BibleDS;
import data.DataAccessInterface;

@RequestScoped
@Path("/bible")

public class BibleRestService 
{
	@Inject
	BibleBusinessInterface service;
	
	List<Bibleverse> bv = new ArrayList<Bibleverse>();
	
	@GET
	@Path("/getjson")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Bibleverse> getVerse(@DefaultValue("1") @QueryParam("b") int book,
			@DefaultValue("1") @QueryParam("c") int chapter,
			@DefaultValue("1") @QueryParam("v") int verse)
	{
		return service.findByAddress(book, chapter, verse);
	}
	@GET
	@Path("/getjson/{b}/{c}/{v}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Bibleverse> getBibleverse1(@PathParam("b") int book, @PathParam("c") int chapter, @PathParam("v") int verse)
	{
		return service.findByAddress(book, chapter, verse);
	}
}
