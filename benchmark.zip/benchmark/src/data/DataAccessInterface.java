package data;

import java.util.List;

import javax.ejb.Local;

public interface DataAccessInterface <Bibleverse>
{
	public List<beans.Bibleverse> findByAddress(int book, int chapter, int verse);
}
