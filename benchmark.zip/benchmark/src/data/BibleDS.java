package data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;

import beans.Bibleverse;
import business.BibleBS;

public class BibleDS implements DataAccessInterface<Bibleverse> {
	public String url = "jdbc:postgresql://localhost:5432/postgres";
	public String username = "postgres";
	public String password = "root";
	
	public BibleDS() 
	{
		
	}

	@Override
	public List<Bibleverse> findByAddress(int book, int chapter, int verse) 
	{
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		List<Bibleverse> bv = new ArrayList<Bibleverse>();
		try 
		{
			conn = DriverManager.getConnection(url, username, password);
			stmt = conn.prepareStatement("SELECT * FROM bible.t_kjv WHERE b = ? AND c = ? AND v = ?");
			stmt.setInt(1, book);
			stmt.setInt(2, chapter);
			stmt.setInt(3, verse);
		
			rs = stmt.executeQuery();

			
			while(rs.next())
			{
				bv.add(new Bibleverse(rs.getInt("b"), rs.getInt("c"),rs.getInt("v"),rs.getString("t")));
				
			}
			rs.close();
		} 
		catch (SQLException e) 
		{	
			e.printStackTrace();
		}
		finally 
		{ 
			if(conn != null) 
			{ 
				try 
				{  
					conn.close(); 
				} 
				catch (SQLException e) 
				{ 
					e.printStackTrace();		
				}
			}
		}
		return bv;
	}
}

