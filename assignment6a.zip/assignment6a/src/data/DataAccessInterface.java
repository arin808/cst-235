package data;

import java.util.List;

public interface DataAccessInterface <Order>
{
	public List<Order> findAll();
	public Order findById(int id);
	public boolean create(Order order);
	public boolean update(Order order);
	public boolean delete(Order order);
}
