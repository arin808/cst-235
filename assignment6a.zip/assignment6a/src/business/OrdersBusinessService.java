package business;


import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;

import beans.Order;
import data.OrdersDataService;

@Stateless
@Local(OrdersBusinessInterface.class)
@LocalBean
@Alternative 


public class OrdersBusinessService implements OrdersBusinessInterface 
{
	
	@EJB
	OrdersDataService service;
	
    public void test() 
    {
    	System.out.println("Hey there from the OrdersBusinessService.");
    }

	@Override
	public List<Order> getOrders() 
	{	
		return service.findAll();
	}

	public boolean deleteOrder(Order order)
	{
		return service.delete(order);
	}

	
	public Order findById(int id) 
	{
		return service.findById(id);
	}

	
	public boolean insertOrder(Order order) 
	{
		
		return service.create(order);
	}

	
	public boolean updateOrder(Order order) 
	{
		return service.update(order);
	}

	@Override
	public void setOrders(List<Order> orders) {
		// TODO Auto-generated method stub
		
	}
}
