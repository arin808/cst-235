package data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;

import beans.Order;

@Stateless
@Local(DataAccessInterface.class)
@LocalBean

public class OrdersDataService implements DataAccessInterface<Order>
{
	public OrdersDataService()
	{
	}
	
	public List<Order> findAll() 
	{
		Connection conn = null;
		String url = "jdbc:postgresql://localhost:5432/postgres";
		String username = "postgres";
		String password = "root";
		
		String sql = "SELECT * FROM testapp.ORDERS";
		List<Order> orders = new ArrayList<Order>();
		try 
		{
			conn = DriverManager.getConnection(url, username, password);
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next())
			{
				orders.add(new Order(rs.getInt("ID"), rs.getString("ORDER_NO"), rs.getString("PRODUCT_NAME"), rs.getFloat("PRICE"), rs.getInt("QUANTITY")));
			}
			rs.close();
		} 
		catch (SQLException e) 
		{
			System.out.println("Failure.");
			e.printStackTrace();
		}
		finally
		{
			if(conn != null)
			{
				try 
				{
					conn.close();
				} 
				catch (SQLException e) 
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		return orders;
	}


	@Override
	public boolean create(Order order) 
	{
		Connection conn = null;
		String url = "jdbc:postgresql://localhost:5432/postgres";
		String username = "postgres";
		String password = "root";
		
		String sql = "INSERT INTO testapp.ORDERS(ORDER_NO, PRODUCT_NAME, PRICE, QUANTITY) VALUES('001122334455', 'This was inserted new', 25.00, 100)";
		
		try 
		{
			conn = DriverManager.getConnection(url, username, password);
			Statement stmt = conn.createStatement();
			stmt.executeUpdate(sql);
			int rowsInserted = stmt.executeUpdate(sql);
			if (rowsInserted > 0)
			{
				System.out.println("A new order was inserted successfully!");
			}
		} 
		catch (SQLException e) 
		{
			System.out.println("Failure.");
			e.printStackTrace();
		}
		finally
		{
			if(conn != null)
			{
				try 
				{
					conn.close();
				} 
				catch (SQLException e) 
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return true;
	}
	
	public boolean update(Order order) 
	{
		Connection conn = null;
		String url = "jdbc:postgresql://localhost:5432/postgres";
		String username = "postgres";
		String password = "root";
		
		String sql = "UPDATE testapp.orders SET PRODUCT_NAME = 'update prod12' WHERE ID = 12";
		
		try 
		{
			conn = DriverManager.getConnection(url, username, password);
			Statement stmt = conn.createStatement();
			stmt.executeUpdate(sql);
			
			int rowsUpdated = stmt.executeUpdate(sql);
			if (rowsUpdated > 0)
			{
				System.out.println("An order was updated successfully!");
			}
		} 
		catch (SQLException e) 
		{
			System.out.println("Failure.");
			e.printStackTrace();
		}
		finally
		{
			if(conn != null)
			{
				try 
				{
					conn.close();
				} 
				catch (SQLException e) 
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return true;
	}

	@Override
	public boolean delete(Order order) 
	{
		Connection conn = null;
		String url = "jdbc:postgresql://localhost:5432/postgres";
		String username = "postgres";
		String password = "root";
		
		String sql = "DELETE FROM testapp.orders WHERE ID = 14";
		
		 
		try 
		{
			conn = DriverManager.getConnection(url, username, password);
			Statement stmt = conn.createStatement();
			stmt.executeUpdate(sql);
			int rowsDeleted = stmt.executeUpdate(sql);
			if (rowsDeleted > 0)
			{
				System.out.println("An order was deleted successfully!");
			}
		} 
		catch (SQLException e) 
		{
			System.out.println("Failure.");
			e.printStackTrace();
		}
		finally
		{
			if(conn != null)
			{
				try 
				{
					conn.close();
				} 
				catch (SQLException e) 
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return false;
	}
		
	@Override
	public Order findById(int id) 
	{
		Connection conn = null;
		String url = "jdbc:postgresql://localhost:5432/postgres";
		String username = "postgres";
		String password = "root";
		
		String sql = "SELECT * FROM testapp.ORDERS WHERE ID = 'id'";
		Order order = null;
		try 
		{
			conn = DriverManager.getConnection(url, username, password);
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next())
			{
				order = new Order(rs.getInt("ID"), rs.getString("ORDER_NO"), rs.getString("PRODUCT_NAME"), rs.getFloat("PRICE"), rs.getInt("QUANTITY"));
			}
			rs.close();
		} 
		catch (SQLException e) 
		{
			System.out.println("Failure.");
			e.printStackTrace();
		}
		finally
		{
			if(conn != null)
			{
				try 
				{
					conn.close();
				} 
				catch (SQLException e) 
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		return order;
	}
	
}
