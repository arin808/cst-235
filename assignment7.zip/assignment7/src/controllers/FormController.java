package controllers;

import java.util.List;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import beans.Order;
import beans.User;
import business.OrdersBusinessInterface;

@ManagedBean
@ViewScoped 

public class FormController {

	@Inject
	OrdersBusinessInterface service;
	
	public String onLogoff()
	{
		FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
		
		return "TestResponse.xhtml?faces-redirect=true";
	}
	public OrdersBusinessInterface getService() 
	{
		return service;
	}
}
