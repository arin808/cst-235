package business;

import javax.ejb.Local;

@Local

public interface OrdersBusinessInterface 
{
	public void test();
	
}
