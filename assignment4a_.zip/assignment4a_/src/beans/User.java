package beans;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@ManagedBean
@ViewScoped

public class User 
{
	@NotNull(message = "Please enter a Firstname. This is a required field.")
	@Size(min=5, max=15)
	String firstName = "";
	
	@NotNull(message = "Please enter a Lastname. This is a required field.")
	@Size(min=5, max=15, message = "Lastname: '${validatedValue}' must be between {min} and {max} characters.")
	String lastName = "";
	
	public User()
	{
		firstName = "Arin";
		lastName = "Aihara";
	}

	
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
}
