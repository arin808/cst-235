package beans;


import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

@ManagedBean
@ViewScoped

public class Orders 
{
	List<Order> orders = new ArrayList<Order>();
	
	public Orders()
	{
		this.orders.add(new Order("0001", "Gibson", (float) 599.99, 3));
		this.orders.add(new Order("0002", "Fender", (float) 699.99, 5));
		this.orders.add(new Order("0003", "Taylor", (float) 799.99, 3));
		this.orders.add(new Order("0004", "Martin", (float) 499.99, 2));
		this.orders.add(new Order("0005", "Takamine", (float) 299.99, 5));
		this.orders.add(new Order("0006", "Pono", (float) 79.99, 6));
		this.orders.add(new Order("0007", "Kamaka", (float) 99.99, 7));
		this.orders.add(new Order("0008", "Twelver", (float) 999.99, 2));
		this.orders.add(new Order("0009", "Guilele", (float) 199.99, 4));
	}

	public List<Order> getOrders() {
		return orders;
	}

	public void setOrders(List<Order> orders) {
		this.orders = orders;
	}
	
}
