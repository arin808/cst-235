package beans;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@ManagedBean
@ViewScoped

public class User 
{
	@NotNull(message = "Please fill out the required fields. It must be between 1 and 15 characters.")
	@Size(min=1, max=15)
	String firstName = "";
	@NotNull(message = "Please fill out the required fields. It must be between 1 and 15 characters.")
	@Size(min=1, max=15)
	String lastName = "";
	
	public User()
	{
		firstName = "Arin";
		lastName = "Aihara";
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
}
